
 <div class="container marketing">
<footer>
	  <p><br></p>
        <p>&copy; 2016 MonTech, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
      </footer>
	      </div><!-- /.container -->