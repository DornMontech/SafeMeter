	if(beerType =="Full Strength")
	{
		if(beerCon == "glass")
			bf = 1.1;
		if(beerCon=="bottle")
			bf=1.4
		if()
	}
	
	if(beerType=="Mid Strength")
	{
		if.....
	}
	
	if(beerType == "Low Strength")
	{
		
	}