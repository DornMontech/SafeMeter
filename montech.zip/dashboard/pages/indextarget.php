 <style>
  .container {
    width: 600px;
    margin: 91px auto;
    text-align: center;
  }

  .gauge {
    width: 235px;
    height: 235px;
    display: inline-block;
  }

  </style>
  
  <div id="gg1" class="gauge"></div>
  <script src="../js/raphael-2.1.4.min.js"></script>
  <script src="../js/justgage.js"></script>
  <script>
  document.addEventListener("DOMContentLoaded", function(event) {

    var dflt = {
      min: 0,
      max:100 ,
      donut: true,
      gaugeWidthScale: 0.6,
      counter: true,
      hideInnerShadow: true
    }

    var gg1 = new JustGage({
      id: 'gg1',
      value: <?php echo $tresult['sumcost']/$trest["target_money"] *100;?>,
     symbol: "%",
      defaults: dflt
    });
    

  });
  </script>
  <br/>
  <b>Your budget limit is : $ <?php echo $trest["target_money"];?>, spent $ <?php echo $tresult["sumcost"]+0 ;?>.</b><a href="targets.php">(details)</a>
  