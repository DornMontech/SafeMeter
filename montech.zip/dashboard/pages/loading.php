<?php
	header("location: targets.php");
?>