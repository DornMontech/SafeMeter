 <ul class="nav" id="side-menu">                       
      
    <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-plus fa-fw"></i> Add drinking record<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="beeradd.php">Beer</a>
                                </li>
                                <li>
                                    <a href="wineadd.php">Wine</a>
                                </li>
								<li>
                                    <a href="spiritsadd.php">Spirits</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
						
						 <li>
                            <a href="records.php"><i class="fa fa-glass"></i> Drinking history</a>
                        </li>
						
						 <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i> Manage targets<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="targets.php">Current Target</a>
                                </li>
                                <li>
                                    <a href="pasttargets.php">Past Targets</a>
                                </li>
								
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>  
					
						 <li>
                            <a href="weekly.php"><i class="fa fa-users"></i> Weekly Comparsion</a>
                        </li>
      
                      
</ul>
