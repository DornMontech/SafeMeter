<?php
	ob_start();
	session_start();
	require_once 'db/dbconn.php';
	
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	else
	{
	$res=mysql_query("SELECT * FROM clients WHERE cname= '".$_SESSION['user']."'");

	$userRow=mysql_fetch_array($res);
	}
	
	$cid = $userRow["cid"];
	
	$query = "SELECT * FROM user_drink WHERE user_id ='".$cid."'";
	$records = mysql_query($query);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome</title>
<!-- Bootstrap core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="bootstrap/docs/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="boost/docs/assets/js/ie-emulation-modes-warning.js"></script>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

 <div class="navbar-wrapper">
    <div class="container">

        <nav class="navbar navbar-light" style="background-color: #e3f2fd">
			 <div class="container">
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				  <a class="navbar-brand" href="index.php">Safe-O-Meter</a>
				</div>
				
				<div id="navbar" class="navbar-collapse collapse">
					<ul class="nav navbar-nav">
					<li class="active"><a href="index.php">Home</a></li>
					<li><a href="suggest.php">Drink Suggestion</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="home.php">Profile</a></li>    
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#"><span class="glyphicon glyphicon-user"></span>&nbsp;Hi, <?php echo $userRow['cname']; ?></a></li>  
						<li>              
						<a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
					</ul>
					
			  
				
				</div>
			
			</div>
        </nav>

    </div>
 </div>
	
<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column">		
		
		<form name ="formInput" Method="Post" Action="insert.php" id='beerForm'>
		<table class="table">
		<tr>
		<td>
			<select name = "drinkName" id="drinkName">
		  <option value="Full Strength">Beer</option>
		  <option value="Mid Strength">Wine</option>
		  <option value="Low Strength">Champagne</option>	
		  <option value="Low Strength">Spirits</option>	
		</td>
		<td>
		Type:  <select id="drinkType" name= "drinkType">
		  <option value="">Please Choose</option>
		  <option value="Full Strength">Full Strength</option>
		  <option value="Mid Strength">Mid Strength</option>
		  <option value="Low Strength">Low Strength</option>	
		  <option value="Full strength ready-to-drink">Full strength ready-to-drink</option>
		  <option value="High strength ready-to-drink">High strength ready-to-drink</option>
		  <option value="Full strength pre-mix spirits">Full strength pre-mix spirits</option>	
		 <option value="High strength pre-mix spirits">High strength pre-mix spirits</option>
		</select>
		</td>
		<td>
		Quantity(ml):
			<select id="qty" name="qty">
		  <option value="285">285</option>
		  <option value="375">375</option>
		  <option value="425">425</option>	
		  <option value="30">30</option>
		  <option value="100">100</option>
		  <option value="150">150</option>	
		  <option value="660">660</option>
		  <option value="750">750</option>		
		</select>
		</td>		
		<td><input type="submit" value="Submit"></td>
		</tr>
		</form>		
		
		
		</div>
	</div>
	
	<p>&nbsp;</p>
	<table class = "table">
   <caption><h3>My Record</h3></caption>
  <tr><th>Drink Name</th>
  <th>Drink Type</th>
  <th>Quantity</th>
  <th>Time</th>
  </tr>
	<?php
	
while ($record = mysql_fetch_assoc($records)) {
    echo '<tr>';
   
        echo '<td>' . $record['drink_name'] . '</td>';
		echo '<td>' . $record['drink_type'] . '</td>';
		echo '<td>' . $record['qty'] . 'ml</td>';
		echo '<td>' . $record['recorded_time'] . '</td>';
    
    echo '</tr>';
}

echo "</table>"; //Close the table in HTML

mysql_close();
?>
</div>
	
	

	
	
 <!-- FOOTER -->
      <?php
		include 'footer.php';
	  ?>



</body>
</html>